<?php
// Copyright 2026 Rino Vincenti. Licensed under GNU GPL v3 or later.
namespace local_sectioncolors;
defined('MOODLE_INTERNAL') || die();
final class palette {
    public const COLORS = [
        'blue' => '#dbeafe', 'green' => '#dcfce7', 'yellow' => '#fef9c3',
        'orange' => '#ffedd5', 'pink' => '#fce7f3', 'purple' => '#ede9fe',
        'teal' => '#ccfbf1', 'gray' => '#e5e7eb',
        'red' => '#fecaca',
        'coral' => '#f8b4a6',
        'peach' => '#ffd6b0',
        'gold' => '#f5d76e',
        'lime' => '#d9f99d',
        'mint' => '#a7f3d0',
        'cyan' => '#a5f3fc',
        'indigo' => '#c7d2fe',
        'rose' => '#f9a8d4',
        'sand' => '#e7d3b0',
    ];
    public static function options(): array {
        $options = ['' => get_string('default', 'local_sectioncolors')];
        foreach (self::COLORS as $key => $hex) {
            $options[$key] = get_string($key, 'local_sectioncolors');
        }
        return $options;
    }
}
