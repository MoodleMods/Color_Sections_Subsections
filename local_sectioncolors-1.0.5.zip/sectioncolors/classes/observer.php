<?php
// Copyright 2026 Rino Vincenti. Licensed under GNU GPL v3 or later.
namespace local_sectioncolors;
defined('MOODLE_INTERNAL') || die();
final class observer {
    public static function course_deleted(\core\event\course_deleted $event): void {
        global $DB;
        $DB->delete_records('local_sectioncolors', ['courseid' => $event->objectid]);
    }
    public static function section_deleted(\core\event\course_section_deleted $event): void {
        global $DB;
        $DB->delete_records('local_sectioncolors', ['sectionid' => $event->objectid]);
    }
}
