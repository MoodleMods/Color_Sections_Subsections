<?php
// Copyright 2026 Rino Vincenti. Licensed under GNU GPL v3 or later.
namespace local_sectioncolors\form;
defined('MOODLE_INTERNAL') || die();
global $CFG;
require_once($CFG->libdir . '/formslib.php');
class colors extends \moodleform {
    public function definition() {
        $mform = $this->_form;
        $mform->addElement('hidden', 'id', $this->_customdata['courseid']);
        $mform->setType('id', PARAM_INT);
        foreach ($this->_customdata['sections'] as $id => $label) {
            $name = 'color_' . $id;
            $mform->addElement('select', $name, $label, \local_sectioncolors\palette::options());
            $mform->setType($name, PARAM_ALPHANUMEXT);
            $mform->setDefault($name, $this->_customdata['values'][$id] ?? '');
        }
        $this->add_action_buttons(true, get_string('savechanges'));
    }
    public function validation($data, $files) {
        $errors = parent::validation($data, $files);
        foreach ($this->_customdata['sections'] as $id => $label) {
            $name = 'color_' . $id;
            if (!array_key_exists($data[$name] ?? '', \local_sectioncolors\palette::options())) {
                $errors[$name] = get_string('invalidcolor', 'local_sectioncolors');
            }
        }
        return $errors;
    }
}
