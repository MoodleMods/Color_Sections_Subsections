<?php
// Copyright 2026 Rino Vincenti. Licensed under GNU GPL v3 or later.
namespace local_sectioncolors\privacy;
defined('MOODLE_INTERNAL') || die();
class provider implements \core_privacy\local\metadata\null_provider {
    public static function get_reason(): string {
        return 'privacy:metadata';
    }
}
