<?php
// Copyright 2026 Rino Vincenti. Licensed under GNU GPL v3 or later.
namespace local_sectioncolors;
defined('MOODLE_INTERNAL') || die();

/** Walk real course activity order rather than delegated-section storage order. */
final class section_order {
    public static function get(\course_modinfo $modinfo): array {
        $all = $modinfo->get_section_info_all();
        uasort($all, static function($a, $b) {
            return $a->section <=> $b->section;
        });
        $delegated = [];
        foreach ($all as $section) {
            if (!empty($section->component) && !empty($section->itemid)) {
                $delegated[$section->component][$section->itemid] = $section;
            }
        }
        $ordered = [];
        $walk = function($section) use (&$walk, &$ordered, $delegated, $modinfo) {
            // Guard against duplicates or malformed nesting cycles.
            if (isset($ordered[$section->id])) {
                return;
            }
            $ordered[$section->id] = $section;
            foreach ($modinfo->sections[$section->section] ?? [] as $cmid) {
                $cm = $modinfo->get_cm($cmid);
                $child = $delegated['mod_' . $cm->modname][$cm->instance] ?? null;
                if ($child !== null) {
                    $walk($child);
                }
            }
        };
        foreach ($all as $section) {
            if (empty($section->component)) {
                $walk($section);
            }
        }
        // Retain access to settings for unmatched delegated sections.
        foreach ($all as $section) {
            $walk($section);
        }
        return $ordered;
    }
}
