<?php
// Copyright 2026 Rino Vincenti. Licensed under GNU GPL v3 or later.
namespace local_sectioncolors;
defined('MOODLE_INTERNAL') || die();
final class output {
    public static function head(\core\hook\output\before_standard_head_html_generation $hook): void {
        global $PAGE, $DB;
        $course = $PAGE->course;
        if (empty($course->id) || $course->id == SITEID || !isloggedin()) {
            return;
        }
        $records = $DB->get_records('local_sectioncolors', ['courseid' => $course->id]);
        $css = '';
        if ($records) {
            $modinfo = get_fast_modinfo($course);
            $sections = [];
            foreach ($modinfo->get_section_info_all() as $section) {
                $sections[$section->id] = $section;
            }
            foreach ($records as $record) {
                if (!isset(palette::COLORS[$record->color], $sections[$record->sectionid])) {
                    continue;
                }
                $section = $sections[$record->sectionid];
                $id = (int)$section->id;
                $selectors = ["#course-index #course-index-section-{$id} > .courseindex-item"];
                $hex = palette::COLORS[$record->color];
                // Style each direct activity, never a nested subsection wrapper.
                $css .= "#course-index #course-index-section-{$id} > .courseindex-item-content "
                    . "{background-color:#fff !important;}";
                foreach ($modinfo->sections[$section->section] ?? [] as $cmid) {
                    $cm = $modinfo->get_cm($cmid);
                    if ($cm->modname === 'subsection') {
                        continue;
                    }
                    $activityid = (int)$cm->id;
                    // Color only the activity name text on the main course page.
                    // Icons, inline editing controls, dates and availability stay outside.
                    $maintitle = "#module-{$activityid} .activityname .instancename";
                    $css .= "$maintitle {background-color:$hex !important;color:#172033 !important;"
                        . "display:inline !important;border-radius:3px;padding:2px 3px;"
                        . "-webkit-box-decoration-break:clone;box-decoration-break:clone;}";
                    $row = "#course-index #course-index-cm-{$activityid}.courseindex-item";
                    $link = "$row > .courseindex-link";
                    // Keep indentation, completion icons and trailing space uncolored.
                    $css .= "$row {background-color:#fff !important;color:#172033 !important;}";
                    $css .= "$link {background-color:$hex !important;color:#172033 !important;"
                        . "flex:0 1 auto !important;width:auto !important;min-width:0;max-width:100%;"
                        . "border-radius:3px;padding-inline:2px;}";
                    // Use a title outline instead of a full-width active blue bar.
                    $css .= "$row.pageitem > .courseindex-link, $row.active > .courseindex-link "
                        . "{outline:2px solid #334155;outline-offset:-2px;font-weight:600;}";
                }
                // Exact section title IDs also identify native subsection titles.
                // Avoid descendant section selectors, which would color nested headings.
                $heading = "#sectionid-{$id}-title";
                $css .= "$heading {background-color:$hex !important;border-inline-start:4px solid #64748b;"
                    . "border-radius:5px;padding:.35rem .65rem;color:#172033 !important;}";
                $css .= "$heading a:not(.dimmed) {color:#172033 !important;}";
                foreach ($selectors as $selector) {
                    // Keep Moodle's active-item highlight and keyboard focus indication intact.
                    $target = $selector . ':not(.pageitem):not(.active)';
                    $css .= "$target {background-color:$hex !important;border-inline-start:4px solid #64748b;"
                        . "border-radius:5px;color:#172033 !important;}";
                    $css .= "$target > .courseindex-link:not(.dimmed), $target > a:not(.dimmed) "
                        . "{color:#172033 !important;}";
                }
            }
        }
        if ($css !== '') {
            $hook->add_html(\html_writer::tag('style', $css));
        }
        $context = \context_course::instance($course->id);
        if (has_capability('moodle/course:update', $context)) {
            $url = new \moodle_url('/local/sectioncolors/edit.php', ['id' => $course->id]);
            $PAGE->requires->js_call_amd('local_sectioncolors/sidebar', 'init',
                [$url->out(false), get_string('pluginname', 'local_sectioncolors')]);
        }
    }
}
