<?php
// Copyright 2026 Rino Vincenti. Licensed under GNU GPL v3 or later.
defined('MOODLE_INTERNAL') || die();
$string['pluginname'] = 'Section colors';
$string['instructions'] = 'Choose a color for each section or subsection heading in both the left course index and main course page. Colors are visible to everyone in this course. Default removes the custom color.';
$string['privacy:metadata'] = 'Sidebar colors stores course section settings only, with no personal data.';
$string['default'] = 'Default (no color)';
$string['blue'] = 'Blue';
$string['green'] = 'Green';
$string['yellow'] = 'Yellow';
$string['orange'] = 'Orange';
$string['pink'] = 'Pink';
$string['purple'] = 'Purple';
$string['teal'] = 'Teal';
$string['gray'] = 'Gray';
$string['subsection'] = 'Subsection: {$a}';
$string['saved'] = 'Section colors saved.';
$string['invalidcolor'] = 'Choose a color from the list.';
$string['red'] = 'Red';
$string['coral'] = 'Coral';
$string['peach'] = 'Peach';
$string['gold'] = 'Gold';
$string['lime'] = 'Lime';
$string['mint'] = 'Mint';
$string['cyan'] = 'Cyan';
$string['indigo'] = 'Indigo';
$string['rose'] = 'Rose';
$string['sand'] = 'Sand';
