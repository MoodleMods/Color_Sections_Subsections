<?php
// Copyright 2026 Rino Vincenti. Licensed under GNU GPL v3 or later.
defined('MOODLE_INTERNAL') || die();
$callbacks = [[
    'hook' => \core\hook\output\before_standard_head_html_generation::class,
    'callback' => [\local_sectioncolors\output::class, 'head'],
]];
