<?php
// Copyright 2026 Rino Vincenti. Licensed under GNU GPL v3 or later.
defined('MOODLE_INTERNAL') || die();
$observers = [
    ['eventname' => '\\core\\event\\course_deleted', 'callback' => '\\local_sectioncolors\\observer::course_deleted'],
    ['eventname' => '\\core\\event\\course_section_deleted', 'callback' => '\\local_sectioncolors\\observer::section_deleted'],
];
