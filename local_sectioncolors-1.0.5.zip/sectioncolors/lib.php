<?php
// Copyright 2026 Rino Vincenti. Licensed under GNU GPL v3 or later.
defined('MOODLE_INTERNAL') || die();
function local_sectioncolors_extend_navigation_course($navigation, $course, $context) {
    if (has_capability('moodle/course:update', $context)) {
        $navigation->add(get_string('pluginname', 'local_sectioncolors'),
            new moodle_url('/local/sectioncolors/edit.php', ['id' => $course->id]),
            navigation_node::TYPE_SETTING, null, 'local_sectioncolors', new pix_icon('i/settings', ''));
    }
}
