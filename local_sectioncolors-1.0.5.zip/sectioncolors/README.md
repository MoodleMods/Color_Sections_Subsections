# Section colors 1.0.5

Installable Moodle local plugin: `local_sectioncolors`. Beta release.
Designed for Moodle 4.5–5.2 with a Boost-compatible course index and native subsections.

## Changes in 1.0.5
Activity title text on the main course page now matches its containing section or subsection color. Highlighting follows wrapped text and excludes icons, editing controls, dates and availability notices.

## Changes in 1.0.4
Sidebar activity titles now match their containing section or subsection color, with color limited to the title link. The indentation and unused space remain white; active activities receive an outline. Nested subsections keep their own independently chosen colors.

## Changes in 1.0.3
Adds Red, Coral, Peach, Gold, Lime, Mint, Cyan, Indigo, Rose and Sand: 18 colors plus Default. Existing palette keys and saved choices are unchanged.

## Changes in 1.0.2
Color settings now follow course order: parent sections followed by their subsections in activity order, including nested delegated sections. Color choices stay attached to their existing section IDs.

## Upgrade from 1.0.0 or 1.0.1
Install this ZIP as an update to local_sectioncolors and complete the Moodle upgrade. Existing color choices are retained; do not uninstall first. The button is now named Section colors.

## Install
Upload local_sectioncolors-1.0.5.zip under Site administration > Plugins > Install plugins.
Complete the database upgrade. No existing Moodle files need replacement.
Manual alternative: put the extracted sectioncolors folder in the local directory next to other local plugins, then visit Site administration > Notifications.
For Moodle distributions using a public web root, that directory is public/local.

## Use
Open a course as an editing teacher or administrator. Click Section colors above the left course index (also available through course navigation / More, depending on the theme).
Choose a color for each section or subsection, then Save changes. Default removes a color.
Matching colors apply to section and subsection headings in the left course index and main course page, for all course viewers. In the sidebar, activity titles use their containing section or subsection color. Indentation and unused row space stay white. The active activity has an outlined, bold title. Main-page activity title text also uses the matching background color. Icons, dates, editing controls and section bodies remain unchanged.
The palette uses pale backgrounds and dark text. Subsections have independent choices.

## Scope and limitations
No changes to core files; no external requests. Only users with moodle/course:update can change settings. Saving requires a Moodle session key. Color records contain course ID, section ID and palette key, without user data. Deleting sections/courses removes associated settings. Uninstalling through Moodle removes the plugin table.
Course backup/restore and duplicated sections do not copy color settings in this version; choose colors again in the copy.
Custom themes/course formats that replace the standard course index, third-party nested subsections, and the Moodle mobile app are not verified.
Validation: JavaScript syntax and mocked DOM behavior (delayed index rendering, button insertion, duplicate prevention and replacement recovery), database XML parsing, ZIP structure and manual source review against Moodle course-index templates. PHP and a browser executable were unavailable, so PHP lint, full Moodle installation/upgrade and live browser integration tests have not been run.

## License
Copyright 2026 Rino Vincenti. GNU General Public License v3 or later.
https://www.gnu.org/licenses/gpl-3.0.html
