<?php
// Copyright 2026 Rino Vincenti. Licensed under GNU GPL v3 or later.
defined('MOODLE_INTERNAL') || die();
$plugin->component = 'local_sectioncolors';
$plugin->version = 2026110205;
$plugin->requires = 2024100700;
$plugin->maturity = MATURITY_BETA;
$plugin->release = '1.0.5';
