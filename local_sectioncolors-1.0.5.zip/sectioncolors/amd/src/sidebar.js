// Licensed under GNU GPL v3 or later.
define([], function() {
    'use strict';
    return {
        init: function(url, label) {
            const addButton = function() {
                const index = document.getElementById('course-index');
                if (!index) { return; }
                if (document.getElementById('local-sectioncolors-button')) { return; }
                const link = document.createElement('a');
                link.id = 'local-sectioncolors-button';
                link.href = url;
                link.textContent = label;
                link.className = 'btn btn-outline-secondary btn-sm m-2';
                index.parentNode.insertBefore(link, index);
            };
            addButton();
            let queued = false;
            new MutationObserver(function() {
                if (queued) { return; }
                queued = true;
                window.requestAnimationFrame(function() { queued = false; addButton(); });
            }).observe(document.body, {childList: true, subtree: true});
        }
    };
});
